import java.lang.Exception;
import java.net.Socket;
import java.io.*;

public class Hilo_Procesador extends Thread {

	private Socket skCliente;
	private DataInputStream input=null;
	private DataOutputStream out=null;

	
	public Hilo_Procesador(Socket p_cliente)
	{
		this.skCliente = p_cliente;
	}
	
	/*
	* Lee datos del socket. Supone que se le pasa un buffer con hueco 
	*	suficiente para los datos. Devuelve el numero de bytes leidos o
	* 0 si se cierra fichero o -1 si hay error.
	*/
	public String leeSocket (Socket p_sk, String p_Datos)
	{
        
		byte[] lista= new byte[1000];
		byte tempb2 = 0;
		int i = 0;
		try
		{
			InputStream aux = p_sk.getInputStream();
			DataInputStream flujo = new DataInputStream( aux );
			p_Datos = new String();

			do
			{
				tempb2 = flujo.readByte();	
                lista[i] = tempb2;
                i++;

			}while(flujo.available() > 0);


			p_Datos= new String (lista, "UTF-8");
			
		}
		catch (Exception e)
		{
			System.out.println("Error: " + e.toString());
		}
      return p_Datos;
	}

	/*
	* Escribe dato en el socket cliente. Devuelve numero de bytes escritos,
	* o -1 si hay error.
	*/
	
	
/*
	public int pedirLRC(String petic){
		int LRC=0;
		for(int i=0;i<petic.length();i++){
			if(i==0){
				LRC=petic.charAt(i);
			}else{
				LRC=LRC^petic.charAt(i);
			}
		}
		System.out.println("LRC="+LRC);
		return LRC;
	}
	
	*/


	public void minimo(Socket p_sk, String info){
		System.out.println(info);
	//	boolean on=false;
		String estado="";
		String partes[]=info.split("-");
		try{
			String file="";
			file=partes[0]+".txt";
			System.out.println(file);
			FileReader read=new FileReader(file);
			BufferedReader read2=new BufferedReader(read);
			
		
			
			String linea=read2.readLine();
			System.out.println(partes[0]);
				while (linea!=null) {
					if(linea.split("=")[0].equals("Floor")){
						if(partes.length==3){
							ReplaceString holi=new ReplaceString();
							String[] todo=new String[3];
							todo[0]=file;
							todo[1]=linea;
							todo[2]="Floor="+partes[1];
							holi.main(todo);
						}					
						estado=linea.split("=")[1];

				//		if(estado.equals("ON")){
				//			on=true;
				//		}
					}
					linea=read2.readLine();
				}
			

			read=new FileReader(file);
			read2=new BufferedReader(read);
			
			
			linea=read2.readLine();
				while (linea!=null) {
					if(linea.split("=")[0].equals("Estado")){
											
						estado=linea.split("=")[1];

				//		if(estado.equals("ON")){
				//			on=true;
				//		}
					}
					linea=read2.readLine();
				}



			System.out.println(estado);
			String decir="";
			if(estado.equals("ON")){
				decir="Activado";
			}

			if(estado.equals("OFF")){
				decir="Desactivado";
			}
			if(partes.length==3){
				String cadena2=new String("Ok. Se ha cambiado el estado a "+ decir);
				OutputStream aux = p_sk.getOutputStream();
				DataOutputStream esc= new DataOutputStream(aux);
		//		esc.writeByte(2);
		//		for(int j=0;j<cadena2.length();j++){
					esc.writeUTF(cadena2);
		//		}
		//		esc.writeByte(3);
		//		esc.writeByte(this.pedirLRC(cadena2));
				esc.flush();
			}	
			if(partes.length==2){

				String cadena2=new String("Ok. "+ decir);
				OutputStream aux = p_sk.getOutputStream();
				DataOutputStream esc= new DataOutputStream(aux);
		//		esc.writeByte(2);
		//		for(int j=0;j<cadena2.length();j++){
					esc.writeUTF(cadena2);
		//		}
		//		esc.writeByte(3);
		//		esc.writeByte(this.pedirLRC(cadena2));
				esc.flush();
				
			}	
			
		}
		catch(Exception e){
			System.out.println("Error: " + e.toString());

		}

	}

	public class ReplaceString{
      public void main(String[] args)throws Exception {
        if(args.length<3)System.exit(0);
        String targetStr = args[1];
        String altStr = args[2];
        java.io.File file = new java.io.File(args[0]);
        java.util.Scanner scanner = new java.util.Scanner(file);
        StringBuilder buffer = new StringBuilder();
        while(scanner.hasNext()){
          buffer.append(scanner.nextLine().replaceAll(targetStr, altStr));
          if(scanner.hasNext())buffer.append("\n");
        }
        scanner.close();
        java.io.PrintWriter printer = new java.io.PrintWriter(file);
        printer.print(buffer);
        printer.close();
      }
    }



	public void estado(Socket p_sk, String info){
		System.out.println(info);
	//	boolean on=false;
		String estado="";
		String partes[]=info.split("-");
		try{
			String file="";
			file=partes[0]+".txt";
			System.out.println(file);
			FileReader read=new FileReader(file);
			BufferedReader read2=new BufferedReader(read);
			
		
			
			String linea=read2.readLine();
			System.out.println(partes[0]);
				while (linea!=null) {
					if(linea.split("=")[0].equals("Estado")){
						if(partes.length==3){
							String nuevo="OFF";
							if(partes[1].equals("1")){
								nuevo="ON";
							}
							ReplaceString holi=new ReplaceString();
							String[] todo=new String[3];
							todo[0]=file;
							todo[1]=linea;
							todo[2]="Estado="+nuevo;
							holi.main(todo);
						}					
						estado=linea.split("=")[1];

				//		if(estado.equals("ON")){
				//			on=true;
				//		}
					}
					linea=read2.readLine();
				}
			

			read=new FileReader(file);
			read2=new BufferedReader(read);
			
			
			linea=read2.readLine();
				while (linea!=null) {
					if(linea.split("=")[0].equals("Estado")){
											
						estado=linea.split("=")[1];

				//		if(estado.equals("ON")){
				//			on=true;
				//		}
					}
					linea=read2.readLine();
				}



			System.out.println(estado);
			String decir="";
			if(estado.equals("ON")){
				decir="Activado";
			}

			if(estado.equals("OFF")){
				decir="Desactivado";
			}
			if(partes.length==3){
				String cadena2=new String("Ok. Se ha cambiado el estado a "+ decir);
				OutputStream aux = p_sk.getOutputStream();
				DataOutputStream esc= new DataOutputStream(aux);
		//		esc.writeByte(2);
		//		for(int j=0;j<cadena2.length();j++){
					esc.writeUTF(cadena2);
		//		}
		//		esc.writeByte(3);
		//		esc.writeByte(this.pedirLRC(cadena2));
				esc.flush();
			}	
			if(partes.length==2){

				String cadena2=new String("Ok. "+ decir);
				OutputStream aux = p_sk.getOutputStream();
				DataOutputStream esc= new DataOutputStream(aux);
		//		esc.writeByte(2);
		//		for(int j=0;j<cadena2.length();j++){
					esc.writeUTF(cadena2);
		//		}
		//		esc.writeByte(3);
		//		esc.writeByte(this.pedirLRC(cadena2));
				esc.flush();
				
			}	
			
		}
		catch(Exception e){
			System.out.println("Error: " + e.toString());

		}

	}
	

	public void index(Socket p_sk, String ok){

	}


    
    public void run() {
		int resultado=0;
		String Cadena="";
		
        try {

			Cadena = this.leeSocket (skCliente, Cadena);
			System.out.println(Cadena);
			
			String partes[]=Cadena.split("\\+");


			String tipo=partes[0];
			tipo=tipo.substring(tipo.length()-3,tipo.length());
            String resto=partes[1];

			System.out.println(tipo);


            for(int i=2;i<partes.length;i++){
                resto=resto.concat("-");
                resto=resto.concat(partes[i]);
            }



			if(tipo.equals("est")){
				this.estado(skCliente, resto);
			}else{
				if(tipo.equals("aut")){
			//		this.auto(skCliente, resto);
					skCliente.close();
				}else{
					if(tipo.equals("min")){
			//			this.minimo(skCliente, resto);
						skCliente.close();
					}
					else{
						if(tipo.equals("max")){
			//				this.maximo(skCliente, resto);
							skCliente.close();
						}
						else{
							if(tipo.equals("ind")){
						//		this.index(skCliente, resto);
						skCliente.close();
							}

						}
					}
				}
			}
				



			/*
			* Se escribe en pantalla la informacion que se ha recibido del
			* cliente
			

			Cadena = "Operacion realizada con exito";
			this.escribeSocket (skCliente, Cadena);						
		*/
			//skCliente.close();
			//System.exit(0); No se debe poner esta sentencia, porque en ese caso el primer cliente que cierra rompe el socket 
			//				  y desconecta a todos				
        }
        catch (Exception e3) {
          System.out.println("Error: " + e3.toString());

		  try{
			  skCliente.close();
		  }catch (Exception e4) {
          	System.out.println("Error: " + e4.toString());
		  }

        }
      }
}
